package com.example.cliente_minerva.config;

import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    public static final String EXCHANGE_NAME = "product_exchange"; //puente
    public static final String QUEUE_NAME_UPDATE = "product_queue_update"; // actualizar
    public static final String QUEUE_NAME_REQUEST = "product_queue_request"; // inventario de otro nodo
    public static final String QUEUE_NAME_RESPONSE  = "product_queue_response"; // inventario de otro nodo
    public static final String QUEUE_NAME_SAVE = "product_queue_save"; // guardar


    // Define el Exchange
    @Bean
    public TopicExchange exchange() {
        return new TopicExchange(EXCHANGE_NAME);
    }

    // Define la cola para actualizaciones
    @Bean
    public Queue queueUpdate() {
        return new Queue(QUEUE_NAME_UPDATE);
    }

    // Define la cola para guardar datos
    @Bean
    public Queue queueSave() {
        return new Queue(QUEUE_NAME_SAVE);
    }

    // Define la cola para solicitudes
    @Bean
    public Queue queueRequest() {
        return new Queue(QUEUE_NAME_REQUEST);
    }

    // Define la cola para respuestas
    @Bean
    public Queue queueResponse() {
        return new Queue(QUEUE_NAME_RESPONSE);
    }
    //----------------------------------------------------------------------------//

    // Vincula la cola de actualizaciones con el Exchange usando la routing key "inventory.update"
    @Bean
    public Binding binding(Queue queueUpdate, TopicExchange exchange) {
        return BindingBuilder.bind(queueUpdate).to(exchange).with("inventory.update");
    }

    @Bean
    public Binding bindingRequest(Queue queueRequest, TopicExchange exchange) {
        return BindingBuilder.bind(queueRequest).to(exchange).with("inventory.request");
    }

    @Bean
    public Binding bindingResponse(Queue queueResponse, TopicExchange exchange) {
        return BindingBuilder.bind(queueResponse).to(exchange).with("inventory.response");
    }

    @Bean
    public Binding bindingSave(Queue queueSave, TopicExchange exchange) {
        return BindingBuilder.bind(queueSave).to(exchange).with("inventory.save");
    }

}

