package com.example.store_central.services;

import com.example.store_central.config.RabbitMQConfig;
import com.example.store_central.models.ProductModel;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class RabbitMQListener {

    private final ProductService productService;
    private Set<String> clients = new HashSet<>();
    private Set<String> clientsDispo = new HashSet<>();
    private String solicitud_client = "";

    @Autowired
    private RabbitMQConfig config;
    @Autowired
    private RabbitTemplate rabbitTemplate; // Inyectamos RabbitTemplate

    public RabbitMQListener(ProductService productService){
        this.productService = productService;
    }


    // Ping de un unico cliente (varios canales) al servidor
    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME_RESPONSE_PING)
    public void PigClientServer(String cliente) {
        try {
            String[] parts = cliente.split(":");
            String client = parts[0];
            System.out.println("Ping recibido por el cliente: "+ client);
            // hayq mejorar esta parte
            solicitud_client = "OK";
            clientsDispo.add(cliente);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al procesar el PING del cliente " + cliente);
        }
    }


    // Ping de varios clientes (sobre un solo un canal) al servidor
    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME_PING)
    public void PigClientsServer(String cliente) {
        try {
            System.out.println("El cliente " + cliente + " ha enviado ping");
            clients.add(cliente);   //anyadimos cliente, para posible futuro
            sendPingClient(cliente);       //contestamos -> "Estoy vico"
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al procesar el PING del cliente " + cliente);
        }
    }

    // Metodo para el servidor: recibir datos del cliente
    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME_SYNC_CLIENT)
    public void receiveClientData(String jsonMessage) {
        try {
            ProductModel product = new ObjectMapper().readValue(jsonMessage, ProductModel.class);
            productService.saveProduct(product);
            System.out.println("Producto sincronizado desde el cliente: " + jsonMessage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ESCUCHAR LAS RESPUESTAS, NORMALMENTE SE USA PARA CONSULTAR INVENTARIOS DE NODOS CLIENTES
    // Nodo Central: RabbitListener para escuchar solicitudes
    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME_REQUEST)
    public void receiveRequestMessage(String message) {
        try {
            System.out.println("Solicitud recibida: " + message);

            // Dividimos el mensaje por ":"
            String[] parts = message.split(":");
            if (parts.length < 2) {
                System.out.println("Error: mensaje mal formado.");
                return;
            }

            String clienteId = parts[0];
            String messageType = parts[1];
            clients.add(clienteId);
            switch (messageType) {
                case "inventory":
                    if (parts.length > 3) {
                        String targetNodeId = parts[2];
                        requestNodo(clienteId, targetNodeId);
                    } else {
                        System.out.println("Error: mensaje de 'inventory' mal formado.");
                    }
                    break;

                case "inventory.product":
                    if (parts.length > 3) {
                        Long targetNodeId = Long.valueOf(parts[2]);
                        Long productId = Long.valueOf(parts[3]);
                        requestOnlyNode(clienteId, targetNodeId, productId);
                    } else {
                        System.out.println("Error: mensaje de 'inventory.product' mal formado.");
                    }
                    break;

                case "Global.inventory":
                    System.out.println("Cliente " + clienteId + " solicita inventario global de todos los nodos.");
                    break;

                default:
                    System.out.println("Error: tipo de mensaje no reconocido: " + messageType);
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al procesar la solicitud");
        }
    }
// DEVUELVE EL INVENTARIO DE UN CLIENTE
    //--------------------------------------------------------------------------------------------------------------------//

    private void requestNodo(String emisor, String receptor) {
        System.out.println("El cliente " + emisor + " esta solicitando el invntario completo del nodo: " + receptor);
        System.out.println("Verificando si el cliente esta activo ......");
        sendPingClient(receptor);
        timeResponse(1);

        if (solicitud_client.equals("OK")) {
            System.out.println("Ping realizado con exito: ....");

            try {
                Long receptorId = Long.parseLong(receptor);
                //productService.getProductsByNode(receptorId);
                System.out.println("Enviando datos al cliente que lo solicito ..... ");
                //sendPingClient(emisor);
                List<ProductModel> aux = productService.getProductsNode(receptorId);
                sendProductToClient(aux, emisor);
            } catch (NumberFormatException e) {
                System.out.println("Error: El receptor no es un id valido.");
                e.printStackTrace();
            }
        } else {
            System.out.println("Error al comunicarse con el cliente");
        }
    }

    // DEVUELVE EL PRODUCTO DE UN INVENTARIO DE UN CLIENTE
    private void requestOnlyNode(String emisor, Long receptor, Long productId){
        System.out.println("Cliente " + emisor + " solicita producto " + productId + " del nodo: " + receptor);
        System.out.println("Verificando si el cliente esta activo");
        sendPingClient(receptor.toString());
        timeResponse(1);
        if (solicitud_client.equals("OK")) {
            System.out.println("Ping realizado con exito: ....");
            try {
                System.out.println("Enviando datos al cliente que lo solicito ..... ");
                Optional<ProductModel> product = productService.getProductByClientAndId(receptor, productId);
                sendProductOnlyToClient(product, emisor);
            } catch (NumberFormatException e) {
                System.out.println("Error: El receptor no es un id valido.");
                e.printStackTrace();
            }
        } else {
            System.out.println("Error al comunicarse con el cliente");
        }
    }

    // DEVUELVE EL PRODUCTO DE UN INVENTARIO DE LOS CLIENTES ACTIVOS/DISPONIBLES
    private void requestAllNode (String emisor, Long productId){
        System.out.println("Cliente " + emisor + " solicita inventario global de todos los nodos para un producto.");
        System.out.println("Verificamos los clientes disponibles");
        for(String cliente : clients){
            sendPingClient(cliente);
        }
        timeResponse(3);
        for (String dispoClient: clientsDispo){
            if (solicitud_client.equals("OK")) {
                System.out.println("Ping realizado con exito: ....");
                try {
                    System.out.println("Enviando datos al cliente que lo solicito ..... ");
//                    Optional<ProductModel> product = productService.getProductByClientAndId(receptor, productId);
//                    sendProductOnlyToClient(product, emisor);
                } catch (NumberFormatException e) {
                    System.out.println("Error: El receptor no es un id valido.");
                    e.printStackTrace();
                }
            } else {
                System.out.println("Error al comunicarse con el cliente");
            }
        }
    }

    //------------------------------------------------------------------------------------------------------//

    private void sendPingClient(String client) {
        try {
            String pingServer = "ACK";
            //confRabbit.setClient(client);
            rabbitTemplate.convertAndSend(RabbitMQConfig.EXCHANGE_NAME, "server.ping."+ client, pingServer);
            System.out.println("Ping enviado al cliente " + pingServer );
            // VAMOS A SUPONER QUE HAY PING CON EL CLIENTE EMISOR
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void sendProductToClient(List<ProductModel> datos, String emisor) {
        try{
            config.setClient(emisor);
            String jsonMessage = new ObjectMapper().writeValueAsString(datos);
            rabbitTemplate.convertAndSend(RabbitMQConfig.EXCHANGE_NAME, "server.response.inventary."+emisor, jsonMessage);
            config.setClient("");
            System.out.println("Los datos se han enviado al cliente: " + solicitud_client);
        }catch (JsonProcessingException e){
            e.printStackTrace();
        }
    }


    private void sendProductOnlyToClient(Optional<ProductModel> datos, String emisor) {
        try{
            config.setClient(emisor);
            String jsonMessage = new ObjectMapper().writeValueAsString(datos);
            rabbitTemplate.convertAndSend(RabbitMQConfig.EXCHANGE_NAME, "server.response.inventary."+emisor, jsonMessage);
            config.setClient("");
            System.out.println("Los datos se han enviado al cliente: " + solicitud_client);
        }catch (JsonProcessingException e){
            e.printStackTrace();
        }
    }


    // esperamos un cacho
    public void timeResponse(long time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    public String getSolicitud_client() {
        return solicitud_client;
    }

    public void setSolicitud_client(String solicitud_client) {
        this.solicitud_client = solicitud_client;
    }


    public Set<String> getClients() {
        return clients;
    }
}