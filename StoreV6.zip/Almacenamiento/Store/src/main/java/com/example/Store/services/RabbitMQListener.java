package com.example.Store.services;

import com.example.Store.config.RabbitMQConfig;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RabbitMQListener {
    private String ping = "";
    private String aux_ping = "";

    //Escucha las confirmaciones del servidor central
    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME_RESPONSE_PING)
    public void receivePingServer(String message) {
        try {
            if (message.contains("ACK")){
                this.ping = "OK";
                //ping = "OK";
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al procesar el mensaje recibido");
        }
    }


    public String getPing() {
        return ping;
    }

    public void setPing(String ping) {
        this.ping = ping;
    }

    public String getAux_ping() {
        return aux_ping;
    }

    public void setAux_ping(String aux_ping) {
        this.aux_ping = aux_ping;
    }

}