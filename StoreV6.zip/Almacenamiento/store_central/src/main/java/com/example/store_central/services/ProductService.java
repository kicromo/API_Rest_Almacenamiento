package com.example.store_central.services;

import com.example.store_central.config.RabbitMQConfig;
import com.example.store_central.models.ProductModel;
import com.example.store_central.repositories.IProductRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    // inyeccion de dependencias
    @Autowired
    IProductRepository productRepository;

    @Autowired
    private RabbitTemplate rabbitTemplate; // Inyectamos RabbitTemplate
    private static final String EXCHANGE_NAME = "product_exchange"; // Nombre del Exchange

    public ProductService(IProductRepository productRepository, RabbitTemplate rabbitTemplate) {
        this.productRepository = productRepository;
        this.rabbitTemplate = rabbitTemplate;
    }


    // Metodo para obtener productos según el targetNodeId
    public void getProductsByNode(Long ClientId) {
        // Buscar productos por clienteId (o targetNodeId)
        List<ProductModel> products = productRepository.findByClienteId(ClientId);

        try {
            String productsJson = new ObjectMapper().writeValueAsString(products);
            rabbitTemplate.convertAndSend(EXCHANGE_NAME, "inventory.response", productsJson);
            System.out.println("Productos enviados al nodo cliente: " + productsJson);

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al convertir los productos a JSON o enviarlos.");
        }
    }

    public ArrayList<ProductModel> getProducts(){
        return (ArrayList<ProductModel>) productRepository.findAll();
    };

    public ProductModel saveProduct(ProductModel product){
        return productRepository.save(product);
    }

    // optinal devuelve algo o null
    public Optional<ProductModel> getById(Long id){
        return productRepository.findById(id);
    }

    public ProductModel updateById(ProductModel request, Long id){
        ProductModel product = productRepository.findById(id).get();

        product.setNombreProducto(request.getNombreProducto());
        product.setCantidadStock(request.getCantidadStock());
        product.setPrecioUnitario(request.getPrecioUnitario());
        product.setCategoria(request.getCategoria());
        product.setFechaultimaActualizacion(request.getFechaultimaActualizacion());
        product.setHistorialMovimientos(request.getHistorialMovimientos());

        return product;
    }

    public Boolean deleteProduct (Long id){
        try {
            productRepository.deleteById(id);
            return true;
        }catch (Exception e){
            return false;
        }
    }

    // Nuevo metodo para actualizar el stock de un producto.
    public void updateStock(ProductModel modelo, Long productId, Long newStock) {
        Optional<ProductModel> optionalProduct = productRepository.findById(productId);

        if (optionalProduct.isPresent()) {
            ProductModel product = optionalProduct.get();
            product.setCantidadStock(newStock);
            productRepository.save(product);
            System.out.println("Inventario actualizado para el producto ID: " + productId + ", nuevo stock: " + newStock);
        } else {
            System.out.println("El producto no esta presente ");
        }
    }
}
