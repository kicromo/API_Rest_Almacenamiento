package com.example.store_central.services;

import com.example.store_central.config.RabbitMQConfig;
import com.example.store_central.models.ProductModel;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

@Service
public class RabbitMQListener {

    private final ProductService productService;

    public RabbitMQListener(ProductService productService){
        this.productService = productService;
    }

    // Escucha todas las colas que le llegan
    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME_REQUEST)
    public void receiveRequestMessage(String dato) {
        try {
            System.out.println("Nuevo dato recibido: " + dato);
            ProductModel product = new ObjectMapper().readValue(dato, ProductModel.class);
            String state = product.getStatus();
            switch (state){
                case "add_product":
                    productService.saveProduct(product);
                break;
                case "inventary_client":
                    Long targetNodeId = Long.valueOf(dato.split(":")[1]);
                    productService.getProductsByNode(targetNodeId);
                default:
                    System.out.println("se ha producido un error");
                    break;
            }
//            if (message.contains("inventory.request")) {
//                Long targetNodeId = Long.valueOf(message.split(":")[1]);
//                System.out.println("Solicitar inventario del nodo: " + targetNodeId);
//
//                productService.getProductsByNode(targetNodeId);
//            }

            // Aquí puedes devolver los datos del inventario al cliente
        } catch (Exception e){
            e.printStackTrace();
            System.out.println("Error al procesar la solicitud de inventario.");
        }
    }
}