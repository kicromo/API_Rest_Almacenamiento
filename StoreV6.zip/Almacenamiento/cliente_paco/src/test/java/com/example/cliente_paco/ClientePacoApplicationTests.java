package com.example.cliente_paco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientePacoApplicationTests {

	@Test
	void contextLoads() {
	}

}
