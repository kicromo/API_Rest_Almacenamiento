package com.example.Store.services;

import com.example.Store.config.RabbitMQConfig;
import com.example.Store.models.ProductModel;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

@Service
public class RabbitMQListener {

    private final ProductService productService;

    public RabbitMQListener(ProductService productService){
        this.productService = productService;
    }

    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME)
    public void receiveMessage(String message) {
        try {
            // Convierte el JSON recibido en un objeto ProductModel
            ProductModel product = new ObjectMapper().readValue(message, ProductModel.class);
            System.out.println("Producto recibido del nodo cliente: " + message);

            // Llama al servicio para actualizar el producto
            productService.updateStock(product, product.getId(), product.getCantidadStock());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al procesar el mensaje recibido.");
        }
    }
}