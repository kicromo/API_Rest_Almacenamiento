package com.example.store_central.config;

import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    public static final String EXCHANGE_NAME = "product_exchange";
    public static final String QUEUE_NAME_UPDATE = "product_queue_update";
    public static final String QUEUE_NAME_REQUEST = "product_queue_request";


    // Define el Exchange
    @Bean
    public TopicExchange exchange() {
        return new TopicExchange(EXCHANGE_NAME);
    }

    // Define la cola para actualizaciones
    @Bean
    public Queue queueUpdate() {
        return new Queue(QUEUE_NAME_UPDATE);
    }

    // Define la cola para solicitudes
    @Bean
    public Queue queueRequest() {
        return new Queue(QUEUE_NAME_REQUEST);
    }

    // Vincula la cola de actualizaciones con el Exchange usando la routing key "inventory.update"
    @Bean
    public Binding bindingUpdate(Queue queueUpdate, TopicExchange exchange) {
        return BindingBuilder.bind(queueUpdate).to(exchange).with("inventory.update");
    }

    // Vincula la cola de solicitudes con el Exchange usando la routing key "inventory.request"
    @Bean
    public Binding bindingRequest(Queue queueRequest, TopicExchange exchange) {
        return BindingBuilder.bind(queueRequest).to(exchange).with("inventory.request");
    }
}
