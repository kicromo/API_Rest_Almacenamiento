package com.example.store_central;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StoreCentralApplication {

	public static void main(String[] args) {
		SpringApplication.run(StoreCentralApplication.class, args);
	}

}
