package com.example.cliente_paco.repositories;

import com.example.cliente_paco.models.ProductModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// consultas a una base de datos
@Repository
public interface IProductRespository extends JpaRepository<ProductModel, Long> {


}
