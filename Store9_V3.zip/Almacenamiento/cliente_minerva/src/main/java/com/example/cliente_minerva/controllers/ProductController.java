package com.example.cliente_minerva.controllers;

import com.example.cliente_minerva.models.ProductModel;
import com.example.cliente_minerva.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/store_minerva")
public class ProductController {


    @Autowired
    private ProductService productService;

    @GetMapping
    public ArrayList<ProductModel> getProducts(){
        return this.productService.getProducts();
    }

    @GetMapping(path="/{id}")
    public Optional<ProductModel> getProductById(@PathVariable("id") Long id){
        return this.productService.getById(id);
    }

    @DeleteMapping(path = "/{id}")
    public String deleteById(@PathVariable("id") Long stock){
        return this.productService.deleteProduct(stock);
    }

    @DeleteMapping(path = "/{id}/{reduceStock}")
    public String deleteById(@PathVariable("id") Long id, @PathVariable("reduceStock") Long reduceStock) {
        return this.productService.deleteProduct(id, reduceStock);
    }

    //        ---------------- PING SERVER ------------ //
    @GetMapping("/inventory/{nodeId}")
    public ArrayList<ProductModel> getInventoryFromNode(@PathVariable Long nodeId) {
        return productService.getInventoryFromOtherNode(nodeId);
    }

    @GetMapping("/inventory/{nodeId}/{productId}")
    public ArrayList<ProductModel> getProductFromNode(@PathVariable Long nodeId, @PathVariable Long productId) {
        return productService.getProductFromOtherNode(nodeId, productId);
    }

    @GetMapping("/inventory/global/{productId}")
    public ArrayList<ProductModel> getGlobalInventory(@PathVariable Long productId) {
        return productService.getGlobalInventoryForProduct(productId);
    }
    // hay que solicitar "traer inventario de otro cliente"



    //--------------------------- Metodos que pueden servir que de momento no lo vamos a usar --------------//
    //@PutMappaing -> http
    //@RequestBody -> puerto/prodcut -> peticiones http
    @PostMapping
    public ProductModel saveProduct(@RequestBody ProductModel product){
        return this.productService.saveProduct(product);
    }


    @PutMapping(path="/{id}")
    public ProductModel updateProductById(@RequestBody ProductModel request, @PathVariable("id") Long id){
        request.setStatus("updateById");
        return this.productService.updateById(request, id);
    }


}
