package com.example.Store.services;

import com.example.Store.models.ProductModel;
import com.example.Store.repositories.IProductRespository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Optional;

@Service
public class ProductService {
    // inyeccion de dependencias
    @Autowired
    IProductRespository productRespository;

    public ArrayList<ProductModel> getProducts(){
        return (ArrayList<ProductModel>) productRespository.findAll();
    };

    public ProductModel saveProduct(ProductModel product){
        return productRespository.save(product);
    }

    // optinal devuelve algo o null
    public Optional<ProductModel> getById(Long id){
        return productRespository.findById(id);
    }

    public ProductModel updateById(ProductModel request, Long id){
        ProductModel product = productRespository.findById(id).get();

        product.setNombreProducto(request.getNombreProducto());
        product.setCantidadStock(request.getCantidadStock());
        product.setPrecioUnitario(request.getPrecioUnitario());
        product.setCategoria(request.getCategoria());
        product.setFechaultimaActualizacion(request.getFechaultimaActualizacion());
        product.setHistorialMovimientos(request.getHistorialMovimientos());

        return product;
    }

    public Boolean deleteProduct (Long id){
        try {
            productRespository.deleteById(id);
            return true;
        }catch (Exception e){
            return false;
        }
    }
}
