package com.example.store_central.models;

import jakarta.persistence.*;

@Entity
@Table(name="/Products")
public class ProductModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    private String nombreProducto;

    @Column
    private Long cantidadStock;

    @Column
    private Long precioUnitario;

    @Column
    private Long Categoria;

    @Column
    private String fechaultimaActualizacion;

    @Column
    private String historialMovimientos;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public Long getCantidadStock() {
        return cantidadStock;
    }

    public void setCantidadStock(Long cantidadStock) {
        this.cantidadStock = cantidadStock;
    }

    public Long getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(Long precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public Long getCategoria() {
        return Categoria;
    }

    public void setCategoria(Long categoria) {
        Categoria = categoria;
    }

    public String getFechaultimaActualizacion() {
        return fechaultimaActualizacion;
    }

    public void setFechaultimaActualizacion(String fechaultimaActualizacion) {
        this.fechaultimaActualizacion = fechaultimaActualizacion;
    }

    public String getHistorialMovimientos() {
        return historialMovimientos;
    }

    public void setHistorialMovimientos(String historialMovimientos) {
        this.historialMovimientos = historialMovimientos;
    }
}

