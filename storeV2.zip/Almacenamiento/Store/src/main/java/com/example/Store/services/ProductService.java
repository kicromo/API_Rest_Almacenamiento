package com.example.Store.services;

import com.example.Store.models.ProductModel;
import com.example.Store.repositories.IProductRespository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Optional;
@Service
public class ProductService {

    public ProductService(){
    }

    // inyeccion de dependencias
    @Autowired
    IProductRespository productRespository;

    @Autowired
    private RabbitTemplate rabbitTemplate; // Inyectamos RabbitTemplate

    private static final String EXCHANGE_NAME = "product_exchange"; // Nombre del Exchange


    public ArrayList<ProductModel> getProducts(){
        return (ArrayList<ProductModel>) productRespository.findAll();
    };

    public ProductModel saveProduct(ProductModel product){
        ProductModel savedProduct = productRespository.save(product);
        sendMessageToCentralNode(savedProduct);
        return savedProduct;
    }

    // optinal devuelve algo o null
    public Optional<ProductModel> getById(Long id){
        return productRespository.findById(id);
    }

    public ProductModel updateById(ProductModel request, Long id){
        ProductModel product = productRespository.findById(id).get();

        product.setNombreProducto(request.getNombreProducto());
        product.setCantidadStock(request.getCantidadStock());
        product.setPrecioUnitario(request.getPrecioUnitario());
        product.setCategoria(request.getCategoria());
        product.setFechaultimaActualizacion(request.getFechaultimaActualizacion());
        product.setHistorialMovimientos(request.getHistorialMovimientos());

        ProductModel updatedProduct = productRespository.save(product);
        //sendMessageToCentralNode(updatedProduct);
        return updatedProduct;
    }

    public Boolean deleteProduct (Long id){
        try {
            productRespository.deleteById(id);
            //sendMessageToCentralNode("Producto eliminado con id: " + id);
            return true;
        }catch (Exception e){
            return false;
        }
    }

    // Metodo para enviar mensaje al nodo central
    private void sendMessageToCentralNode(ProductModel message) {

        try{
            String jsonMessage = new ObjectMapper().writeValueAsString(message);
            rabbitTemplate.convertAndSend(EXCHANGE_NAME, "inventory.update", jsonMessage);
            System.out.println("Mensaje enviado al nodo central: " + jsonMessage);
        }catch (JsonProcessingException e){
            e.printStackTrace();
        }
    }
}
