package com.example.cliente_minerva.config;

import com.example.cliente_minerva.models.ProductModel;
import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    //private ProductModel model;
    private String clienteId = "33";
    public static final String EXCHANGE_NAME = "product_exchange"; //puente
    public static final String QUEUE_NAME_REQUEST = "product_queue_request"; // envio al servidor
    public static final String QUEUE_NAME_RESPONSE_INVENTARY  = "product_queue_response_inventary"; //rebir datos inventario
    public static final String QUEUE_NAME_SEND_DATO  = "product_queue_send_dato"; // enviamos dato


    public static final String QUEUE_NAME_PING = "product_queue_ping";
    public static final String QUEUE_NAME_RESPONSE_PING ="product_queue_response_ping";
    public static final String QUEUE_NAME_SYNC_CLIENT ="product_queue_sync_client";


    // define el Exchange
    @Bean
    public TopicExchange exchange() {
        return new TopicExchange(EXCHANGE_NAME);
    }


    //----------------------------------------------------------------------------//
    // Define la cola para solicitudes
    @Bean
    public Queue queueRequest() {
        return new Queue(QUEUE_NAME_REQUEST);
    }

    @Bean
    public Queue queueResponseInventary() {
        return new Queue(QUEUE_NAME_RESPONSE_INVENTARY);
    }

    @Bean
    public Queue queuePing() {
        return new Queue(QUEUE_NAME_PING);
    }

    @Bean
    public Queue queueResponsePing() {
        return new Queue(QUEUE_NAME_RESPONSE_PING);
    }

    @Bean
    public Queue queueSendDato() {
        return new Queue(QUEUE_NAME_SEND_DATO);
    }


    @Bean
    public Queue queueSynzClient(){
        return new Queue(QUEUE_NAME_SYNC_CLIENT);
    }

    //---------------------------------------------------------------------------------------------------------------//

    @Bean
    public Binding bindingRequest(Queue queueRequest, TopicExchange exchange) {
        return BindingBuilder.bind(queueRequest).to(exchange).with("server.request"); //solicitar servidor
    }

    @Bean
    public Binding bindingResponseInventary(Queue queueResponseInventary, TopicExchange exchange) {
        return BindingBuilder.bind(queueResponseInventary).to(exchange).with("server.response.inventary."+clienteId); // respuesta servidor
    }

    @Bean
    public Binding bindingPing(Queue queuePing, TopicExchange exchange) {
        return BindingBuilder.bind(queuePing).to(exchange).with("server.ping"); // ping al servidor
    }

    @Bean
    public Binding bindingResponsePing(Queue queueResponsePing, TopicExchange exchange) {
        return BindingBuilder.bind(queueResponsePing).to(exchange).with("server.ping."+clienteId); // clint -> servidor
    }

    @Bean
    public Binding bindingSendDato(Queue queueSendDato, TopicExchange exchange) {
        return BindingBuilder.bind(queueSendDato).to(exchange).with("server.send.dato"); // para enviar dato al servidor
    }

    @Bean
    public Binding bindingSync(Queue queueSynzClient, TopicExchange exchange) {
        return BindingBuilder.bind(queueSynzClient).to(exchange).with("server.sync."+clienteId);
    }
}