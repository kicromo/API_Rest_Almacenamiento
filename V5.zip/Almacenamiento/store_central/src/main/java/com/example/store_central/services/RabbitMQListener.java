package com.example.store_central.services;

import com.example.store_central.config.RabbitMQConfig;
import com.example.store_central.models.ProductModel;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

@Service
public class RabbitMQListener {

    private final ProductService productService;

    public RabbitMQListener(ProductService productService){
        this.productService = productService;
    }


    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME_SAVE)
    public void receiveSaveMessage(String message) {
        try {
            ProductModel product = new ObjectMapper().readValue(message, ProductModel.class);
            System.out.println("Producto recibido para guardar: " + message);

            productService.saveProduct(product);
        } catch (Exception e){
            e.printStackTrace();
            System.out.println("Error al procesar el mensaje de actualización.");
        }
    }

    // a lo mejor hay que quitar ek product
    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME_UPDATE)
    public void receiveUpdateMessage(String message) {
        try {
            // Convierte el JSON recibido en un objeto ProductModel
            ProductModel product = new ObjectMapper().readValue(message, ProductModel.class);
            System.out.println("Producto recibido para actualización: " + message);

            productService.updateStock(product, product.getId(), product.getCantidadStock());
        } catch (Exception e){
            e.printStackTrace();
            System.out.println("Error al procesar el mensaje de actualización.");
        }
    }

    // Escucha las solicitudes de inventario
    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME_REQUEST)
    public void receiveRequestMessage(String message) {
        try {
            System.out.println("Solicitud de inventario recibida: " + message);
            if (message.contains("inventory.request")) {
                Long targetNodeId = Long.valueOf(message.split(":")[1]);
                System.out.println("Solicitar inventario del nodo: " + targetNodeId);

                productService.getProductsByNode(targetNodeId);
            }
            // Aquí puedes devolver los datos del inventario al cliente
        } catch (Exception e){
            e.printStackTrace();
            System.out.println("Error al procesar la solicitud de inventario.");
        }
    }
}