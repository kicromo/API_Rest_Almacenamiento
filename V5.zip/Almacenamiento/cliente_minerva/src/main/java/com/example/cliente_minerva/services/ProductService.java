package com.example.cliente_minerva.services;

import com.example.cliente_minerva.models.ProductModel;
import com.example.cliente_minerva.repositories.IProductRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Optional;
import java.util.concurrent.CountDownLatch;

@Service
public class ProductService {

    // CountDownLatch para sincronización
    private CountDownLatch latch = new CountDownLatch(1);   // similar al semanforo
    private ArrayList<ProductModel> receivedProducts = null; // aqui estaran todos los datos de oto nodo

    public ProductService(){
    }

    // inyeccion de dependencias
    @Autowired
    IProductRepository productRespository;

    @Autowired
    private RabbitTemplate rabbitTemplate; // Inyectamos RabbitTemplate
    private static final String EXCHANGE_NAME = "product_exchange"; // Nombre del Exchange



    //------------------------------------------------------------------------------------------------------//
    // Escucha las respuestas de inventario (se puede mejorar)
    @RabbitListener(queues = "product_queue_response")
    public void receiveResponseMessage(String message) {
        try {
            receivedProducts = new ObjectMapper().readValue(message, new TypeReference<ArrayList<ProductModel>>() {});
            System.out.println("Productos recibidos: " + receivedProducts);

            // Procesa los productos recibidos (mostrarlos, guardarlos, etc.)
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al procesar la respuesta del inventario.");
        } finally {
            latch.countDown();
        }
    }


    public ArrayList<ProductModel> getInventoryFromOtherNode(Long targetNodeId) {
        String requestMessage = "inventory.request:" + targetNodeId;
        try {
            // Enviar mensaje al nodo central
            rabbitTemplate.convertAndSend(EXCHANGE_NAME, "inventory.request", requestMessage);
            System.out.println("Solicitud enviada al nodo central para nodo: " + targetNodeId);

            // Esperar la respuesta de la cola (utilizando el CountDownLatch)
            latch.await();  // Espera a que el latch sea contado a cero

            // Devolver la lista de productos recibidos
            return receivedProducts;
        } catch (InterruptedException e) {
            e.printStackTrace();
            return null;
        }
    }


    public ArrayList<ProductModel> getProducts(){
        return (ArrayList<ProductModel>) productRespository.findAll();
    };

    public ProductModel saveProduct(ProductModel product){
        ProductModel savedProduct = productRespository.save(product);
        sendMessageToCentralNode(savedProduct);
        return savedProduct;
    }

    // optinal devuelve algo o null
    public Optional<ProductModel> getById(Long id){
        return productRespository.findById(id);
    }

    public ProductModel updateById(ProductModel request, Long id){
        ProductModel product = productRespository.findById(id).get();

        product.setNombreProducto(request.getNombreProducto());
        product.setCantidadStock(request.getCantidadStock());
        product.setPrecioUnitario(request.getPrecioUnitario());
        product.setCategoria(request.getCategoria());
        product.setFechaultimaActualizacion(request.getFechaultimaActualizacion());
        product.setHistorialMovimientos(request.getHistorialMovimientos());

        return product;
    }

    public Boolean deleteProduct (Long id){
        try {
            productRespository.deleteById(id);
            return true;
        }catch (Exception e){
            return false;
        }
    }

    // Nuevo metodo para actualizar el stock de un producto.
    public void updateStock(ProductModel modelo, Long productId, Long newStock) {
        Optional<ProductModel> optionalProduct = productRespository.findById(productId);

        if (optionalProduct.isPresent()) {
            ProductModel product = optionalProduct.get();
            product.setCantidadStock(newStock);
            productRespository.save(product);
            System.out.println("Inventario actualizado para el producto ID: " + productId + ", nuevo stock: " + newStock);
        } else {
            saveProduct(modelo);
            System.out.println("Se ha add un nuevo modelo :x ");
        }
    }

    // Metodo para enviar mensaje al nodo central
    private void sendMessageToCentralNode(ProductModel message) {

        try{
            String jsonMessage = new ObjectMapper().writeValueAsString(message);
            rabbitTemplate.convertAndSend(EXCHANGE_NAME, "inventory.save", jsonMessage);
            System.out.println("Mensaje enviado al nodo central: " + jsonMessage);
        }catch (JsonProcessingException e){
            e.printStackTrace();
        }
    }

}
