package com.example.cliente_minerva.controllers;

import com.example.cliente_minerva.models.ProductModel;
import com.example.cliente_minerva.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Optional;

@RestController
@RequestMapping("/store_minerva")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping
    public ArrayList<ProductModel> getProducts() {
        return this.productService.getProducts();
    }


        //****************************//
    //    @GetMapping("/inventory/{targetNodeId}")
    //    public DeferredResult<List<ProductModel>> getInventoryFromOtherNode(@PathVariable Long targetNodeId) {
    //        DeferredResult<List<ProductModel>> deferredResult = new DeferredResult<>();
    //
    //        // Ini solicitud asincrona
    //        productService.getInventoryFromOtherNode(targetNodeId, deferredResult);
    //
    //        return deferredResult;
    //    }

    @GetMapping("/inventory/{nodeId}")
    public ArrayList<ProductModel> getInventoryFromNode(@PathVariable Long nodeId) {
        return productService.getInventoryFromOtherNode(nodeId);
    }

    //@PutMappaing -> http
    //@RequestBody -> puerto/prodcut -> peticiones http
    @PostMapping
    public ProductModel saveProduct(@RequestBody ProductModel product) {
        return this.productService.saveProduct(product);
    }

    @GetMapping(path = "/{id}")
    public Optional<ProductModel> getProductById(@PathVariable("id") Long id) {
        return this.productService.getById(id);
    }

    @PutMapping(path = "/{id}")
    public ProductModel updateProductById(@RequestBody ProductModel request, @PathVariable("id") Long id) {
        return this.productService.updateById(request, id);
    }

    @DeleteMapping(path = "/{id}")
    public String deleteById(@PathVariable("id") Long id) {
        boolean ok = this.productService.deleteProduct(id);
        if (ok) {
            return "User with id deleted" + id;
        } else {
            return "Error, problems deleted the user with id " + id;
        }
    }
}