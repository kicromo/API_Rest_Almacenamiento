package com.example.cliente_paco.services;

import com.example.cliente_paco.config.RabbitMQConfig;
import com.example.cliente_paco.models.ProductModel;
import com.example.cliente_paco.repositories.IProductRespository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
@Service
public class ProductService {

    // CountDownLatch para sincronizacion
    private CountDownLatch latch = new CountDownLatch(1);   // similar al semanforo
    private ArrayList<ProductModel> receivedProducts = null; // aqui estaran todos los datos de oto nodo
    private static String clienteId = "777";
    private String fecha;
    private List<ProductModel> productHistory = new ArrayList<>();


    public ProductService(){}

    @Autowired
    private RabbitMQListener rabbit;

    @Autowired
    private TimeSyncService time;

    // inyeccion de dependencias
    @Autowired
    IProductRespository productRespository;

    @Autowired
    private RabbitTemplate rabbitTemplate; // Inyectamos RabbitTemplate
    private static final String EXCHANGE_NAME = "product_exchange"; // Nombre del Exchange

//--------------------------------------------------------------------------------------------------------------//
// Escucha las respuestas de inventario (se puede mejorar)

    // PEDIMOStoDO EL INVENTARIO DE LA OTRO CLIENTE
    public ArrayList<ProductModel> getInventoryFromOtherNode(Long targetNodeId) {
        try{
            String requestMessage = clienteId + "#inventory.client#" + targetNodeId + "#0000#" + "_#" + time.syncTime();
            try{
                rabbitTemplate.convertAndSend(EXCHANGE_NAME, "product.request", requestMessage);
                System.out.println("Solicitando inventario del cliente: " + targetNodeId);
            }catch (Exception e){
                System.err.println("Error al enviar la solicitud a RabbitMQ: " + e.getMessage());
                e.printStackTrace();
                return new ArrayList<>();
            }
            try{
                requestProductNodes(requestMessage);    // esto contaria como ping + solicitud
            }catch (Exception e){
                System.err.println("Error al procesar nodos: " + e.getMessage());
                e.printStackTrace();
                return new ArrayList<>();
            }
            try{
                return timeResponseForNodo(1000);
            }catch (Exception e){
                System.err.println("Error al esperar la respuesta de los nodos: " + e.getMessage());
                e.printStackTrace();
                return new ArrayList<>();
            }
        }catch (Exception e){
            System.err.println("Error inesperado en getProductFromOtherNode: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }


    // Abria que modificar el array ya que solo tiene que rebir una "dato/objeto" no multiples
    // PEDIMOS UN PRODUCTO DEL INVENTARIO DEL OTRO CLIENTE
    public ArrayList<ProductModel> getProductFromOtherNode(Long targetNodeId, Long productId) {
        try {
            String requestMessage = clienteId + "#inventory.client.product#" + targetNodeId + "#" + productId + "#_#" + time.syncTime();
            try {
                rabbitTemplate.convertAndSend(EXCHANGE_NAME, "product.request", requestMessage);
                System.out.println("Solicitud enviada al nodo central para nodo: " + targetNodeId + ", con producto: " + productId);
            } catch (Exception e) {
                System.err.println("Error al enviar la solicitud a RabbitMQ: " + e.getMessage());
                e.printStackTrace();
                return new ArrayList<>();
            }
            try {
                requestProductNodes(requestMessage);
            } catch (Exception e) {
                System.err.println("Error al procesar nodos: " + e.getMessage());
                e.printStackTrace();
                return new ArrayList<>();
            }

            try {
                return timeResponseForNodo(1000);
            } catch (Exception e) {
                System.err.println("Error al esperar la respuesta de los nodos: " + e.getMessage());
                e.printStackTrace();
                return new ArrayList<>();
            }
        } catch (Exception e) {
            System.err.println("Error inesperado en getProductFromOtherNode: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    //PEDIMOS UN PRODUCTO EN CONCRETO DE TODOS LOS CLIENTES CONECTADOS
    public ArrayList<ProductModel> getGlobalInventoryForProduct(Long productId) {
        try {
            String requestMessage = clienteId + "#global.inventory.product#" + "_" + productId + "#" + "0000" + "#" + time.syncTime();
            try {
                rabbitTemplate.convertAndSend(EXCHANGE_NAME, "product.request", requestMessage);
                System.out.println("Solicitud global desde el cliente: " + clienteId + " sobre el producto: " + productId);
            } catch (Exception e) {
                System.err.println("Error al enviar la solicitud a RabbitMQ: " + e.getMessage());
                e.printStackTrace();
                return new ArrayList<>();
            }
            try {
                requestProductNodes(requestMessage);
            } catch (Exception e) {
                System.err.println("Error al procesar nodos: " + e.getMessage());
                e.printStackTrace();
                return new ArrayList<>();
            }
            try {
                return timeResponseForNodo(1000);
            } catch (Exception e) {
                System.err.println("Error al esperar la respuesta de los nodos: " + e.getMessage());
                e.printStackTrace();
                return new ArrayList<>();
            }
        } catch (Exception e) {
            System.err.println("Error inesperado en getGlobalInventoryForProduct: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    //TRAEMOS EL STOCK DE UN CLIENTE RECEPTOR SI ES POSIBLE
//    public ArrayList<ProductModel> getStockFromAnotherClient(Long targetNodeId, Long productId, Long numReduce) {
//        try {
//            String requestMessage = clienteId + "#inventory.client.reduce.product#" + targetNodeId + "#" + productId + "#_#" + time.syncTime() + numReduce;
//            try {
//                rabbitTemplate.convertAndSend(EXCHANGE_NAME, "product.request", requestMessage);
//                System.out.println("Solicitud enviada al nodo central para nodo: " + targetNodeId + ", con producto: " + productId);
//            } catch (Exception e) {
//                System.err.println("Error al enviar la solicitud a RabbitMQ: " + e.getMessage());
//                e.printStackTrace();
//                return new ArrayList<>();
//            }
//            try {
//                requestProductNodes(requestMessage);
//            } catch (Exception e) {
//                System.err.println("Error al procesar nodos: " + e.getMessage());
//                e.printStackTrace();
//                return new ArrayList<>();
//            }
//
//            try {
//                return timeResponseForNodo(1000);
//            } catch (Exception e) {
//                System.err.println("Error al esperar la respuesta de los nodos: " + e.getMessage());
//                e.printStackTrace();
//                return new ArrayList<>();
//            }
//        } catch (Exception e) {
//            System.err.println("Error inesperado en getProductFromOtherNode: " + e.getMessage());
//            e.printStackTrace();
//            return new ArrayList<>();
//        }
//    }

    //--------------------------------------------------------------------------------------------------------------//

    // CONSULTA LOS STOCKS DE SUS PRODCUTOS DE SU INVENTARIO
    public ArrayList<ProductModel> getProducts(){
        return (ArrayList<ProductModel>) productRespository.findAll();
    };


    // DEVUELVE UN PRODUCTO DE SU PROPIO INVENTARIO
    public Optional<ProductModel> getById(Long id){
        return productRespository.findById(id);
    }


    // ELIMINA UN STOCK DE UN PRODUCTO DE SU INVENTARIO
    public String deleteProduct (Long id){
        pingserver();
        String response = timeResponse(10);
        if (!response.equals("PING recibido.")) {
            System.out.println(response);
        }
        if ("NACK".equals(rabbit.getAux_ping()) && "OK".equals(rabbit.getPing())) {
            System.out.println("Reconexion detectada ..... iniciando sincronizacion de los datos con el servidor.");
            syncWithCentralNode();
        }
        try {
            Optional<ProductModel> optionalProduct = productRespository.findById(id);
            if (optionalProduct.isPresent()) {
                ProductModel product = optionalProduct.get();
                Long newStock = product.getCantidadStock() - 1;
                if (newStock < 0) {
                    return "No se puede reducir mas, el stock ya esta en 0";
                }
                fecha = time.syncTime();
                product.setCantidadStock(newStock);                         // nuev stock
                product.setFechaultimaActualizacion(fecha);       //actualizamos fecha
                if (rabbit.getPing().equals("OK")){
                    String jsonMessage = new ObjectMapper().writeValueAsString(product);
                    String requestMessage = clienteId + "#save.product#" + "_#" + "0000#" + jsonMessage + "#" + fecha;
                    requestProductNodes(requestMessage);
                }else{
                    rabbit.setPing("NACK");
                    System.out.println("No hay conexion con el servidor ... usando datos locamente");
                }
                fecha = "";
                productRespository.save(product);// daots localmente
                productHistory.add(product);        //añadimos producto en el historial
                if (newStock == 10) {
                    return "Stock del producto con ID " + id + " reducido a " + newStock + ". Advertencia: quedan muy pocos productos, se debe reponer.";
                }

                if (newStock == 0) {
                    return "Stock del producto con id " + id + " agotado.";
                }
                return "Stock del producto con id " + id + " reducido a " + newStock;
            } else {
                return "Producto con id " + id + " no encontrado";
            }
        } catch (Exception e) {
            return "Error al reducir el stock del producto con ID " + id;
        }
    }

    // ELIMINAR VARIOS STOCKS DE UN PRODUCTO DE SU INVENTARIO
    public String deleteProduct(Long id, Long reduceStock) {
        pingserver();                                    // enviamos ping
        String response = timeResponse(20);     // esperamos respuesta
        if (!response.equals("PING recibido")) {
            System.out.println(response + "desde delete");
        }

        if ("NACK".equals(rabbit.getAux_ping()) && "OK".equals(rabbit.getPing())) {
            System.out.println("Reconexion detectada. Iniciando sincronizacion.....");
            syncWithCentralNode();
        }
        try {
            Optional<ProductModel> optionalProduct = productRespository.findById(id);
            if (optionalProduct.isPresent()) {
                ProductModel product = optionalProduct.get();
                Long currentStock = product.getCantidadStock();

                if (currentStock < reduceStock) {
                    return "Error: No hay suficiente stock. Solo quedan " + currentStock + " unidades.";
                }
                fecha = time.syncTime();
                Long newStock = currentStock - reduceStock;
                product.setStatus("reduceStock");
                product.setFechaultimaActualizacion(fecha);   // actulizamos fecha
                product.setCantidadStock(newStock);                     // actualizamos stock

                if (rabbit.getPing().equals("OK")){ // ping server correcto
                    String jsonMessage = new ObjectMapper().writeValueAsString(product);
                    String requestMessage = clienteId + "#save.product#" + "_#" + "0000#" + jsonMessage + "#" + fecha;
                    requestProductNodes(requestMessage);
                }else{
                    System.out.println("No hay conexion con el servidor ... usando datos locamente");
                }
                fecha = "";
                productRespository.save(product);
                productHistory.add(product);        //añadimos producto en el historial
                if (newStock == 10) {
                    return "Stock del producto con ID " + id + " reducido a " + newStock + ". Advertencia: quedan muy pocos productos, se debe reponer.";
                }

                if (newStock == 0) {
                    return "Stock del producto con id " + id + " agotado";
                }

                return "Stock del producto con id " + id + " reducido a " + newStock;
            } else {
                return "Producto con id " + id + " no encontrado";
            }
        } catch (Exception e) {
            return "Error al reducir el stock del producto con id: " + id;
        }
    }


//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//

    private void requestProductNodes(String inventaryClient) {
        try{
            rabbitTemplate.convertAndSend(EXCHANGE_NAME, "server.request", inventaryClient);
            System.out.println("Enviando solicitud del cliente: " + inventaryClient);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    // Metodo para sincronizar datos desde el cliente hacia el servidor
    public String syncWithCentralNode() {
        // Bloqueamos momentáneamente el cliente
        synchronized (this) {
            pingserver(); // Verificamos que el servidor esté activo

            if (!rabbit.getPing().equals("OK")) {
                return "No se puede sincronizar, el servidor no está disponible.";
            }

            try {
                // Obtenemos todos los productos de la base de datos local
                List<ProductModel> localProducts = productRespository.findAll();

                for (ProductModel product : localProducts) {
                    // Convertimos cada producto en JSON y lo enviamos al servidor
                    product.setFechaultimaActualizacion(time.syncTime());
                    String jsonMessage = new ObjectMapper().writeValueAsString(product);
                    rabbitTemplate.convertAndSend(EXCHANGE_NAME, "server.sync."+product.getClienteId(), jsonMessage);
                    System.out.println("Producto enviado al nodo central: " + jsonMessage);
                }
                // Esperamos confirmación del servidor
                latch.await(10, TimeUnit.SECONDS);

                if (receivedProducts != null) {
                    // Actualizamos la base de datos local con los datos recibidos del servidor
                    for (ProductModel product : receivedProducts) {
                        productRespository.save(product);
                    }

                    return "Sincronización completada exitosamente.";
                } else {
                    return "Sincronización fallida. El servidor no respondió a tiempo.";
                }
            } catch (Exception e) {
                e.printStackTrace();
                return "Error durante la sincronizacion: " + e.getMessage();
            }
        }
    }


    public String timeResponse(long waitTime) {
        long startTime = System.currentTimeMillis();

        // Almacenamos el estado actual en aux_ping antes de iniciar la espera
        rabbit.setAux_ping(rabbit.getPing());

        while (System.currentTimeMillis() - startTime < waitTime) {
            try {
                if ("OK".equals(rabbit.getPing())) {
                    return "PING recibido";
                } else {
                    Thread.sleep(1);                    // espera activa controlada
                }
            } catch (InterruptedException e) {
                rabbit.setAux_ping(rabbit.getPing());       // guardamos el estado anterior
                rabbit.setPing("NACK");                     // no hay conexión
                e.printStackTrace();
                return "Error en el proceso de espera del servidor. NO SE HAN GUARDADO CAMBIOS.";
            }
        }

        // Si se agota el tiempo, marcamos como "NAcK" y guardamos el estado anterior (Aux9
        rabbit.setAux_ping(rabbit.getPing());
        rabbit.setPing("NACK");
        return "Tiempo de espera agotado. No hay respuesta del servidor.";
    }

    public ArrayList<ProductModel> timeResponseForNodo(long waitTime) {
        long startTime = System.currentTimeMillis();
        while (System.currentTimeMillis() - startTime < waitTime) {
            try {
                if ("OK".equals(rabbit.getAux_ping())) {
                    rabbit.setAux_ping("");
                    return rabbit.getLsitaInv();
                } else {
                    Thread.sleep(5);                    // espera activa controlada
                }
            } catch (InterruptedException e) {
                System.out.println("El tiempo de repuesta ha concluido, error al recibir el dato del servidor");
                e.printStackTrace();
                return null;
            }
        }
        System.out.println("AWWAAW");
        return null;
    }

    private void pingserver (){
        try{
            String pingServer = clienteId;
            rabbitTemplate.convertAndSend(EXCHANGE_NAME, "server.ping", pingServer);
            System.out.println("Ping enviado al nodo central con el cliente: " + pingServer);
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    public List<ProductModel> getLastTenMovements() {
        if (productHistory.size() >= 10) {
            productHistory.remove(0);  // Elimina el producto mas antigui
        }
        return productHistory;
    }

    public void setProductHistory(List<ProductModel> productHistory) {
        this.productHistory = productHistory;
    }
    //------------------------------------------------------------------------------------------------------------------//

    public ProductModel updateById(ProductModel request, Long id){
        ProductModel product = productRespository.findById(id).get();
        product.setNombreProducto(request.getNombreProducto());
        product.setCantidadStock(request.getCantidadStock());
        product.setPrecioUnitario(request.getPrecioUnitario());
        product.setCategoria(request.getCategoria());
        product.setFechaultimaActualizacion(request.getFechaultimaActualizacion());
        product.setHistorialMovimientos(request.getHistorialMovimientos());

        ProductModel updatedProduct = productRespository.save(product);
        //sendMessageToCentralNode(updatedProduct);
        return updatedProduct;
    }


    // ---------------------------- PARA ANYADIR PRODUCTOS MANUALMENTE o ADMIN ------------------------//
    public ProductModel saveProduct(ProductModel product){
        try{
            String fechaSave = time.syncTime();
            product.setFechaultimaActualizacion(fechaSave);
            product.setStatus("add_product");
            ProductModel savedProduct = productRespository.save(product);

            //Le decimos al servidor que lo registre / guarde
            String jsonMessage = new ObjectMapper().writeValueAsString(savedProduct);
            String requestMessage = clienteId + "#save.product#" + "_#" + "0000#" + jsonMessage + "#" + fechaSave;
            requestProductNodes(requestMessage);

            productHistory.add(product);        //añadimos producto en el historial
            System.out.println("Se han anyadido los productos manualmente: " + product.toString());
            return savedProduct;

        } catch (Exception e) {
            System.out.println("Error al anyadir los datos ");
            e.printStackTrace();
            return  null;
        }
    }

    public void updateStock(ProductModel modelo, Long productId, Long newStock) {
        Optional<ProductModel> optionalProduct = productRespository.findById(productId);

        if (optionalProduct.isPresent()) {
            ProductModel product = optionalProduct.get();
            product.setCantidadStock(newStock);
            productRespository.save(product);
            System.out.println("Inventario actualizado para el producto ID: " + productId + ", nuevo stock: " + newStock);
        } else {
            saveProduct(modelo);
            System.out.println("Se ha add un nuevo modelo :x ");
        }
    }

}
