package com.example.cliente_paco.models;

import jakarta.persistence.*;

@Entity
@Table(name="Products_paco")
public class ProductModel {


    @Column
    private Long clienteId = 55L;

    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    // El ID tiene que se unico para cada producto
    @Id
    @Column
    private Long id;        // id del producto

    @Column
    private String nombreProducto;

    @Column
    private Long cantidadStock;

    @Column
    private Long precioUnitario;

    @Column
    private Long Categoria;

    @Column
    private String fechaultimaActualizacion;

    @Column
    private String historialMovimientos;

    @Column
    private String status;     // se muestr vacio


    //---------GETTERS Y SETTERS --------//
    public Long getClienteId() {
        return clienteId;
    }

    public void setClienteId(Long clienteId) {
        this.clienteId = Long.valueOf(String.valueOf(clienteId));
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public Long getCantidadStock() {
        return cantidadStock;
    }

    public void setCantidadStock(Long cantidadStock) {
        this.cantidadStock = cantidadStock;
    }

    public Long getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(Long precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public Long getCategoria() {
        return Categoria;
    }

    public void setCategoria(Long categoria) {
        Categoria = categoria;
    }

    public String getFechaultimaActualizacion() {
        return fechaultimaActualizacion;
    }

    public void setFechaultimaActualizacion(String fechaultimaActualizacion) {
        this.fechaultimaActualizacion = fechaultimaActualizacion;
    }

    public String getHistorialMovimientos() {
        return historialMovimientos;
    }

    public void setHistorialMovimientos(String historialMovimientos) {
        this.historialMovimientos = historialMovimientos;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

