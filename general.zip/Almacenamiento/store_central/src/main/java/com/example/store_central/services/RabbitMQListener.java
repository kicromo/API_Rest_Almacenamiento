package com.example.store_central.services;

import com.example.store_central.config.RabbitMQConfig;
import com.example.store_central.models.ProductModel;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Semaphore;

@Service
public class RabbitMQListener {

    private final ProductService productService;
    private Set<String> clients = new HashSet<>();
    private Set<String> clientsDispo = new HashSet<>();

    // cola de prioridad que mantiene las solicitudes ordenadas por tiempo
    private PriorityQueue<Request> requestQueue = new PriorityQueue<>();

    // hilo para procesar las solicitudes
    private Thread requestProcessorThread;


    @Autowired
    private RabbitMQConfig config;
    @Autowired
    private RabbitTemplate rabbitTemplate; // Inyectamos RabbitTemplate

    public RabbitMQListener(ProductService productService){
        this.productService = productService;
    }


    // Ping de varios clientes (sobre un solo un canal) al servidor
    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME_PING, concurrency = "3-5")
    public void PigClientsServer(String cliente) {
        try {
            System.out.println("Ha llegado un ping .... " + cliente);
            String[] parts = cliente.split(":");
            if(parts.length == 1){ // 777
                System.out.println("El cliente " + cliente + " ha enviado ping");
                clients.add(cliente);   //anyadimos cliente, para posible futuro
                sendPingClient(cliente+":ACK");       //contestamos -> "Estoy vico"
            }else {
                String clientId = parts[0];
                String responseInvent = parts[1];
                clients.add(clientId);
                clientsDispo.add(clientId); // ACK:777
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al procesar el PING del cliente " + cliente);
        }
    }

    // SYNCRONIZACION PARA AQUEL CLIENTE QUE HA PERDIDO CONEXION
    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME_SYNC_CLIENT)
    public void receiveClientData(String jsonMessage) {
        try {
            ProductModel product = new ObjectMapper().readValue(jsonMessage, ProductModel.class);
            productService.saveProduct(product);
            System.out.println("Producto sincronizado desde el cliente: " + jsonMessage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    // ESCUCHAR LAS RESPUESTAS, NORMALMENTE SE USA PARA CONSULTAR INVENTARIOS DE NODOS CLIENTES
    // Nodo Central: RabbitListener para escuchar solicitudes
    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME_REQUEST_AND_DATO, concurrency = "5-10")
    public void receiveRequestMessage(String message) {
        Request request = new Request(message);

        System.out.println("Ha llegado un dato .... " + message);
        // anyadimos la solicitud a la cola de prioridad
        synchronized (requestQueue) {
            requestQueue.offer(request);            //  creamos objeti request
        }

        if (requestProcessorThread == null || !requestProcessorThread.isAlive()) { // inicializado + hilo no vivo
            requestProcessorThread = new Thread(this::processRequests);
            requestProcessorThread.start();
        }

    }

    private void processRequests() {
        while (true) {
            Request request;
            synchronized (requestQueue) {
                if (!requestQueue.isEmpty()) {
                    request = requestQueue.poll(); // solicitud antigua (primero en llegar)
                } else {
                    return;
                }
            }

            System.out.println("Procesando solicitud ....... ");

            switch (request.getMessageType()) {
                case "save.product":
                    saveProduct(request.getClienteId(), request.getJsonMessage());
                    break;
                case "inventory.client":
                    requestNodo(request.getClienteId(), request.getTargetNodeId());
                    break;
                case "inventory.client.product":
                    requestOnlyNode(request.getClienteId(), Long.parseLong(request.getTargetNodeId()), request.getProductId());
                    break;

                case "global.inventory.product":
                    requestAllNode(request.getClienteId(), request.getProductId());
                    break;

                default:
                    System.out.println("Error: tipo de mensaje no reconocido: " + request.getMessage());
                    break;
            }

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

// DEVUELVE EL INVENTARIO DE UN CLIENTE
    //--------------------------------------------------------------------------------------------------------------------//

    private void requestNodo(String emisor, String receptor) {
        System.out.println("El cliente " + emisor + " esta solicitando el invntario completo del nodo: " + receptor);
        System.out.println("Verificando si el cliente esta activo ......");
        sendPingClient(receptor+":inventory");
        //timeResponse(20);

        if (timeResponseOnlyNodo(1000, receptor).equals("OK")) {
            System.out.println("Cliente disponnibles: " + clientsDispo.toString());
            clientsDispo.remove(receptor);
            System.out.println("Ping realizado con exito: ....");

            try {
                Long receptorId = Long.parseLong(receptor);
                System.out.println("Enviando datos al cliente que lo solicito ..... ");
                List<ProductModel> aux = productService.getProductsNode(receptorId);
                sendProductToClient(aux, emisor);
            } catch (NumberFormatException e) {
                System.out.println("Error: El receptor no es un id valido.");
                e.printStackTrace();
            }
        } else {
            sendPingClient(emisor+":NACK");
            System.out.println("Error al comunicarse con el cliente");
        }
    }

    // DEVUELVE EL PRODUCTO DE UN INVENTARIO DE UN CLIENTE
    private void requestOnlyNode(String emisor, Long receptor, Long productId){
        System.out.println("Cliente " + emisor + " solicita producto " + productId + " del nodo: " + receptor);
        System.out.println("Verificando si el cliente esta activo");
        sendPingClient(receptor.toString());
        //timeResponse(100);
        if (timeResponseOnlyNodo(1000, receptor.toString()).equals("OK")) {
            clientsDispo.remove(receptor.toString());
            System.out.println("Ping realizado con exito: ....");
            try {
                System.out.println("Enviando datos al cliente que lo solicito ..... ");
                Optional<ProductModel> product = productService.getProductByClientAndId(receptor, productId);
                product.ifPresent(productModel -> sendProductOnlyToClient(productModel, emisor));

            } catch (NumberFormatException e) {
                System.out.println("Error: El receptor no es un id valido.");
                e.printStackTrace();
            }
        } else {
            sendPingClient(emisor+":NACK");
            System.out.println("Error al comunicarse con el cliente");
        }
    }

    // DEVUELVE EL PRODUCTO DE UN INVENTARIO DE LOS CLIENTES ACTIVOS/DISPONIBLES
    private void requestAllNode (String emisor, Long productId){
        System.out.println("Cliente " + emisor + " solicita inventario global de todos los nodos para un producto.");
        System.out.println("Verificamos los clientes disponibles");
        clients.forEach(this::sendPingClient);

        timeResponse(100);
        // Se utiliza Collections.synchronizedList para evitar problemas de concurrencia al agregar productos encontrados a la lista compartida productList
        List<ProductModel> productList = Collections.synchronizedList(new ArrayList<>());

        //List<Thread> threads = new ArrayList<>();
        List<Thread> threads = getThreads(productId, productList);

        // eperamos a que todos los hilos terminen
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                System.err.println("Hilo interrumpido: " + e.getMessage());
                Thread.currentThread().interrupt();
            }
        }
        clientsDispo.clear();
        sendProductsAllClients(productList, emisor);
    }

    private List<Thread> getThreads(Long productId, List<ProductModel> productList) {
        List<Thread> threads = new ArrayList<>();

        for (String clientId : clientsDispo) {
            Thread thread = new Thread(() -> {
                try {
                    Long clientLongId = Long.valueOf(clientId);
                    productService.getProductByClientAndId(clientLongId, productId)
                            .ifPresent(productList::add);
                } catch (Exception e) {
                    System.err.println("Error procesando cliente " + clientId + ": " + e.getMessage());
                }
            });
            threads.add(thread);
            thread.start(); // Iniciar hilo
        }
        return threads;
    }

    //------------------------------------- METODOS QUE SE PUEDEN PARELELIZAR ----------------------------------------//

    private void sendPingClient(String message) {
        try {
            String[] parts = message.split(":");
            String client = parts[0];
            rabbitTemplate.convertAndSend(RabbitMQConfig.EXCHANGE_NAME, "server.ping."+ client, message);
            System.out.println("Ping enviado al cliente " + client + " con mensaje: " + parts[1]);
            // VAMOS A SUPONER QUE HAY PING CON EL CLIENTE EMISOR
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveProduct(String client, String jsonDato){
        try{
            ProductModel product = new ObjectMapper().readValue(jsonDato, ProductModel.class);
            System.out.println("Recibiendo el dato por el cliente: "+ client);
            productService.saveProduct(product);
            System.out.println("Producto guardado");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void sendProductToClient(List<ProductModel> datos, String emisor) {
        try {
            String routingKey = "server.response.inventary." + emisor;
            String jsonMessage = new ObjectMapper().writeValueAsString(datos);
            rabbitTemplate.convertAndSend(RabbitMQConfig.EXCHANGE_NAME, routingKey, jsonMessage);
            System.out.println("Los datos se han enviado al cliente: " + emisor);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    private void sendProductOnlyToClient(ProductModel datos, String emisor) {
        try {
            String routingKey = "server.response.inventary." + emisor;
            List<ProductModel> productList = new ArrayList<>();
            productList.add(datos);
            String jsonMessage = new ObjectMapper().writeValueAsString(productList);  // Enviamos la lista
            rabbitTemplate.convertAndSend(RabbitMQConfig.EXCHANGE_NAME, routingKey, jsonMessage);
            System.out.println("Los datos se han enviado al cliente: " + emisor);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

    }


    private void sendProductsAllClients(List<ProductModel> datos, String emisor){
        try {
            String routingKey = "server.response.inventary." + emisor;
            String jsonMessage = new ObjectMapper().writeValueAsString(datos);
            rabbitTemplate.convertAndSend(RabbitMQConfig.EXCHANGE_NAME, routingKey, jsonMessage);
            System.out.println("Los datos se han enviado al cliente: " + emisor);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    // esperamos un cacho, esto para consulta global
    public void timeResponse(long time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    public String timeResponseOnlyNodo(long waitTime, String receptor) {
        long startTime = System.currentTimeMillis();
        System.out.println("Cliente disponnibles: " + clientsDispo.toString());

        while (System.currentTimeMillis() - startTime < waitTime) {
            try {
                if (clientsDispo.contains(receptor)) {
                    return "OK";
                } else {
                    Thread.sleep(5);                    // espera activa controlada
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
                return "Error en el proceso de espera del servidor. NO SE HAN GUARDADO CAMBIOS.";
            }
        }

        return "Tiempo de espera agotado. No hay respuesta del servidor.";
    }


    public Set<String> getClients() {
        return clients;
    }
}