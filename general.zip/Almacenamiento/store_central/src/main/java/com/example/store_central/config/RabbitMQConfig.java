package com.example.store_central.config;

import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    public static final String EXCHANGE_NAME = "product_exchange"; //puente
    public static final String QUEUE_NAME_REQUEST_AND_DATO = "product_queue_request"; // RECIBE DATO DIRECTO:  CLIENTE -> SERVIDOR
    public static final String QUEUE_NAME_PING = "product_queue_ping"; // PING GLOBAL: CLIENTES -> SERVIDOR

    public static final String QUEUE_NAME_RESPONSE_INVENTARY  = "product_queue_response_inventary"; // ENVIA INVENT AL CLIENTE
    public static final String QUEUE_NAME_RESPONSE_PING ="product_queue_response_ping"; // PING SERVIDOR -> CLIENTE
    public static final String QUEUE_NAME_SYNC_CLIENT ="product_queue_sync_client";

    private String client = "";

    // Define el Exchange
    @Bean
    public TopicExchange exchange() {
        return new TopicExchange(EXCHANGE_NAME);
    }

    // Define la cola para solicitudes
    @Bean
    public Queue queueRequest() {
        return new Queue(QUEUE_NAME_REQUEST_AND_DATO);
    }

    // Define la cola para respuestas
    @Bean
    public Queue queueResponseInventary() {
        return new Queue(QUEUE_NAME_RESPONSE_INVENTARY);
    }

    // Define la cola para respuestas
    @Bean
    public Queue queuePing() {
        return new Queue(QUEUE_NAME_PING);
    }

    @Bean
    public Queue queueResponsePing() {
        return new Queue(QUEUE_NAME_RESPONSE_PING);
    }


    @Bean
    public Queue queueSynzClient(){
        return new Queue(QUEUE_NAME_SYNC_CLIENT);
    }
    //----------------------------------------------------------------------------//


    @Bean
    public Binding bindingRequest(Queue queueRequest, TopicExchange exchange) {
        return BindingBuilder.bind(queueRequest).to(exchange).with("server.request"); // inventario
    }

    @Bean
    public Binding bindingResponsePing(Queue queuePing , TopicExchange exchange) {
        return BindingBuilder.bind(queuePing).to(exchange).with("server.ping"); // muchoss clientes
    }


    @Bean
    public Binding bindingResponseInventary(Queue queueResponseInventary, TopicExchange exchange) {
        return BindingBuilder.bind(queueResponseInventary).to(exchange).with("server.response.inventary."+client);
    }


    @Bean
    public Binding bindingPing(Queue queueResponsePing, TopicExchange exchange) {
        return BindingBuilder.bind(queueResponsePing).to(exchange).with("server.ping."+client);
    }

    @Bean
    public Binding bindingSync(Queue queueSynzClient, TopicExchange exchange) {
        return BindingBuilder.bind(queueSynzClient).to(exchange).with("server.sync."+client);
    }


    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

}
