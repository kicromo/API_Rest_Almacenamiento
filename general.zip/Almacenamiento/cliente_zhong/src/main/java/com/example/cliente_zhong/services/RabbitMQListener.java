package com.example.cliente_zhong.services;

import com.example.cliente_zhong.config.RabbitMQConfig;
import com.example.cliente_zhong.models.ProductModel;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

@Service
public class RabbitMQListener {
    private String clientId= "44";
    private String ping = "";
    private String aux_ping = "";
    CountDownLatch bloq;
    private List<ProductModel> listaInventary;

    private ArrayList<ProductModel> listaInv;

    @Autowired
    private RabbitTemplate rabbitTemplate; // Inyectamos RabbitTemplate


    //Escucha las confirmaciones del servidor central
    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME_RESPONSE_PING)
    public void receivePingServer(String message) {
        try {
            System.out.println("Ha llegado un mensaje de ping");
            String[] parts = message.split(":");
            //String client = parts[0];
            String type = parts[1];
            if (type.equals("ACK")){
                this.ping = "OK";
            }else if (type.equals("inventory")){
                sendPingServer(clientId);
                // hilo bloqueo
                Thread.sleep(20);
                // confirmacion servidor while () -> sincrono
            }else if (type.equals("NACK")){
                this.ping = "NACK";
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al procesar el mensaje recibido");
        }
    }

    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME_RESPONSE_INVENTARY)
    public void receiveResponseInventary(String message) {
        try {
            // Deserializamos como una lista de productos
            List<ProductModel> productList = new ObjectMapper().readValue(message, new TypeReference<List<ProductModel>>() {});
            System.out.println("Recibidos " + productList.size() + " productos.");
            ArrayList<ProductModel> list = new ArrayList<>(productList);
            listaInv = list;
            aux_ping = "OK";
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }


    private void sendPingServer(String client) {
        try {
            String pingToServer = client+":ACK";
            rabbitTemplate.convertAndSend(RabbitMQConfig.EXCHANGE_NAME, "server.ping", pingToServer);
            System.out.println("Ping enviado al servidor con mensaje: " + pingToServer );

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public ArrayList<ProductModel> getLsitaInv() {
        return listaInv;
    }

    public void setLsitaInv(ArrayList<ProductModel> listaInv) {
        this.listaInv = listaInv;
    }



    public String getPing() {
        return ping;
    }

    public void setPing(String ping) {
        this.ping = ping;
    }

    public String getAux_ping() {
        return aux_ping;
    }

    public void setAux_ping(String aux_ping) {
        this.aux_ping = aux_ping;
    }

}