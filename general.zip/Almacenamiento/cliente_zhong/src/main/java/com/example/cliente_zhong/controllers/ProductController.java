package com.example.cliente_zhong.controllers;

import com.example.cliente_zhong.models.ProductModel;
import com.example.cliente_zhong.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/store_zhong")
public class ProductController {


    private List<ProductModel> productHistory = new ArrayList<>();  // Almacenará los últimos 10 movimientos

    @Autowired
    private ProductService productService;


    // Endpoint para obtener los ultmos 10 movimientos del inventario
    @GetMapping("/history")
    public ResponseEntity<List<ProductModel>> getHistory() {
        List<ProductModel> history = productService.getLastTenMovements();
        return ResponseEntity.ok(history);
    }

    @GetMapping
    public ResponseEntity<ArrayList<ProductModel>> getProducts() {
        try {
            ArrayList<ProductModel> products = this.productService.getProducts();
            return ResponseEntity.ok(products);
        } catch (Exception e) {
            // Manejo de excepciones, puedes loguear el error
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ArrayList<>()); // retorna una lista vacia o un mensaje de error
        }
    }

    @GetMapping(path="/{id}")
    public ResponseEntity<Optional<ProductModel>> getProductById(@PathVariable("id") Long id) {
        try {
            Optional<ProductModel> product = this.productService.getById(id);
            return product.isPresent() ? ResponseEntity.ok(product) :
                    ResponseEntity.status(HttpStatus.NOT_FOUND).body(Optional.empty());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Optional.empty());
        }
    }

    @DeleteMapping(path = "/{id}")
    public ResponseEntity<String> deleteById(@PathVariable("id") Long stock) {
        try {
            String result = this.productService.deleteProduct(stock);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al eliminar el producto");
        }
    }

    @DeleteMapping(path = "/{id}/{reduceStock}")
    public ResponseEntity<String> deleteById(@PathVariable("id") Long id, @PathVariable("reduceStock") Long reduceStock) {
        try {
            String result = this.productService.deleteProduct(id, reduceStock);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al eliminar el producto");
        }
    }

// ---------------- PING SERVER ------------ //

    @GetMapping("/inventory/{nodeId}")
    public ResponseEntity<ArrayList<ProductModel>> getInventoryFromNode(@PathVariable Long nodeId) {
        try {
            ArrayList<ProductModel> inventory = productService.getInventoryFromOtherNode(nodeId);
            return ResponseEntity.ok(inventory);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ArrayList<>());
        }
    }

    @GetMapping("/inventory/{nodeId}/{productId}")
    public ResponseEntity<ArrayList<ProductModel>> getProductFromNode(@PathVariable Long nodeId, @PathVariable Long productId) {
        try {
            ArrayList<ProductModel> product = productService.getProductFromOtherNode(nodeId, productId);
            return ResponseEntity.ok(product);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ArrayList<>());
        }
    }

    @GetMapping("/inventory/global/{productId}")
    public ResponseEntity<ArrayList<ProductModel>> getGlobalInventory(@PathVariable Long productId) {
        try {
            ArrayList<ProductModel> globalInventory = productService.getGlobalInventoryForProduct(productId);
            return ResponseEntity.ok(globalInventory);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ArrayList<>());
        }
    }

//    @GetMapping("/inventory/reduce/{nodeId}/{productId}/{numStock}")
//    public ResponseEntity<ArrayList<ProductModel>> reduceStockOtherClient(@PathVariable Long nodeId, @PathVariable Long productId, @PathVariable Long numStock) {
//        try {
//            ArrayList<ProductModel> productReceptor = productService.getProductFromOtherNode(nodeId, productId, numStock);
//            return ResponseEntity.ok(productReceptor);
//        } catch (Exception e) {
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ArrayList<>());
//        }
//    }




    // hay que solicitar "traer inventario de otro cliente"
    // ResponseEntity, se usa para manejo de peticiones http mas controladas, bien = cuerpo (peticion), mal = error 404


    //--------------------------- Metodos que pueden servir que de momento no lo vamos a usar --------------//
    //@PutMappaing -> http
    //@RequestBody -> puerto/prodcut -> peticiones http
    @PostMapping
    public ProductModel saveProduct(@RequestBody ProductModel product){
        return this.productService.saveProduct(product);
    }


    @PutMapping(path="/{id}")
    public ProductModel updateProductById(@RequestBody ProductModel request, @PathVariable("id") Long id){
        request.setStatus("updateById");
        return this.productService.updateById(request, id);
    }


}
