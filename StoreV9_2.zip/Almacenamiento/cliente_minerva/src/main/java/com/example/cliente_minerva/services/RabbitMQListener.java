package com.example.cliente_minerva.services;

import com.example.cliente_minerva.config.RabbitMQConfig;
import com.example.cliente_minerva.models.ProductModel;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.CountDownLatch;

@Service
public class RabbitMQListener {
    private String clientId= "33";
    private String ping = "";
    private String aux_ping = "";
    CountDownLatch bloq;
    private List<ProductModel> listaInventary;

    @Autowired
    private RabbitTemplate rabbitTemplate; // Inyectamos RabbitTemplate


    //Escucha las confirmaciones del servidor central
    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME_RESPONSE_PING)
    public void receivePingServer(String message) {
        try {
            String[] parts = message.split(":");
            String client = parts[0];
            String type = parts[1];
            if (type.equals("ACK")){
                this.ping = "OK";
            }else if (type.equals("inventory")){
                sendPingServer(clientId);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al procesar el mensaje recibido");
        }
    }

    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME_RESPONSE_INVENTARY)
    public void receiveResponseInventary(String message) {
        try {
            // Deserializamos como una lista de productos
            List<ProductModel> productList = new ObjectMapper().readValue(message, new TypeReference<List<ProductModel>>() {});
            System.out.println("Recibidos " + productList.size() + " productos.");
            listaInventary = productList;
            if (bloq != null) {
                bloq.countDown();
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    public List<ProductModel> getListaInventary() {
        return listaInventary;
    }

    public void setListaInventary(List<ProductModel> listaInventary) {
        this.listaInventary = listaInventary;
    }

    public void setBloq(CountDownLatch bloq) {
        this.bloq = bloq;
    }

    private void sendPingServer(String client) {
        try {
            String pingToServer = client+":inventory";
            rabbitTemplate.convertAndSend(RabbitMQConfig.EXCHANGE_NAME, "server.ping", pingToServer);
            System.out.println("Ping enviado al cliente " + pingToServer );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getPing() {
        return ping;
    }

    public void setPing(String ping) {
        this.ping = ping;
    }

    public String getAux_ping() {
        return aux_ping;
    }

    public void setAux_ping(String aux_ping) {
        this.aux_ping = aux_ping;
    }

}