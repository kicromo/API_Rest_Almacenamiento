package com.example.cliente_minerva.repositories;

import com.example.cliente_minerva.models.ProductModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// consultas a una base de datos
@Repository
public interface IProductRepository extends JpaRepository<ProductModel, Long> {


}
