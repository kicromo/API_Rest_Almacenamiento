package com.example.cliente_zhong.services;

import org.apache.commons.net.ntp.NTPUDPClient;
import org.apache.commons.net.ntp.TimeInfo;
import org.springframework.stereotype.Service;

import java.net.InetAddress;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class TimeSyncService {

    //private static final String NTP_SERVER = "localhost"; // reloj ordenador
    private static final String NTP_SERVER = "pool.ntp.org"; //servicio publico
    private String newDate;
    public String syncTime() {
        NTPUDPClient client = new NTPUDPClient();
        client.setDefaultTimeout(10000);  // reconecion

        try {
            InetAddress inetAddress = InetAddress.getByName(NTP_SERVER);
            TimeInfo timeInfo = client.getTime(inetAddress);
            long time = timeInfo.getMessage().getTransmitTimeStamp().getTime(); // clock server

            Date date = new Date(time);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            //String formattedDate = sdf.format(date);

            System.out.println("Fecha y hora: " + sdf.format(date));
            return sdf.format(date);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

}
